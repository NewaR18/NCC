﻿using Microsoft.AspNetCore.Mvc;

namespace letsdothis.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Create()
        {
            return View("Create");
        }
    }
}

